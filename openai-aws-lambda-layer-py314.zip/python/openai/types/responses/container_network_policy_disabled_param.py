# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["ContainerNetworkPolicyDisabledParam"]


class ContainerNetworkPolicyDisabledParam(TypedDict, total=False):
    type: Required[Literal["disabled"]]
    """Disable outbound network access. Always `disabled`."""
