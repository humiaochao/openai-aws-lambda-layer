# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, List, Optional
from typing_extensions import Literal, Required, TypedDict

__all__ = ["FunctionToolParam"]

_FunctionToolParamReservedKeywords = TypedDict(
    "_FunctionToolParamReservedKeywords",
    {
        "async": bool,
    },
    total=False,
)


class FunctionToolParam(_FunctionToolParamReservedKeywords, total=False):
    """Defines a function in your own code the model can choose to call.

    Learn more about [function calling](https://developers.openai.com/api/docs/guides/function-calling).
    """

    name: Required[str]
    """The name of the function to call."""

    parameters: Required[Optional[Dict[str, object]]]
    """A JSON schema object describing the parameters of the function."""

    strict: Required[Optional[bool]]
    """Whether strict parameter validation is enforced for this function tool."""

    type: Required[Literal["function"]]
    """The type of the function tool. Always `function`."""

    allowed_callers: Optional[List[Literal["direct", "programmatic"]]]
    """The tool invocation context(s)."""

    defer_loading: bool
    """Whether this function is deferred and loaded via tool search."""

    description: Optional[str]
    """A description of the function.

    Used by the model to determine whether or not to call the function.
    """

    output_schema: Optional[Dict[str, object]]
    """
    A JSON schema object describing the JSON value encoded in string outputs for
    this function.
    """
