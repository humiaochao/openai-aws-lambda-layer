# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["ComputerUsePreviewTool"]


class ComputerUsePreviewTool(BaseModel):
    """A tool that controls a virtual computer.

    Learn more about the [computer tool](https://developers.openai.com/api/docs/guides/tools-computer-use).
    """

    display_height: int
    """The height of the computer display."""

    display_width: int
    """The width of the computer display."""

    environment: Literal["windows", "mac", "linux", "ubuntu", "browser"]
    """The type of computer environment to control."""

    type: Literal["computer_use_preview"]
    """The type of the computer use tool. Always `computer_use_preview`."""
