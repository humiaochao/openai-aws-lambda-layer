# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from typing_extensions import Literal, Annotated, TypeAlias

from .tool import Tool
from ..._utils import PropertyInfo
from ..._models import BaseModel
from .mcp_tool_call_error import McpToolCallError
from .response_output_message import ResponseOutputMessage
from .response_reasoning_item import ResponseReasoningItem
from .response_compaction_item import ResponseCompactionItem
from .response_tool_search_call import ResponseToolSearchCall
from .response_computer_tool_call import ResponseComputerToolCall
from .response_input_message_item import ResponseInputMessageItem
from .response_function_web_search import ResponseFunctionWebSearch
from .response_apply_patch_tool_call import ResponseApplyPatchToolCall
from .response_custom_tool_call_item import ResponseCustomToolCallItem
from .response_file_search_tool_call import ResponseFileSearchToolCall
from .response_function_tool_call_item import ResponseFunctionToolCallItem
from .response_tool_search_output_item import ResponseToolSearchOutputItem
from .response_function_shell_tool_call import ResponseFunctionShellToolCall
from .response_configuration_update_item import ResponseConfigurationUpdateItem
from .response_code_interpreter_tool_call import ResponseCodeInterpreterToolCall
from .response_apply_patch_tool_call_output import ResponseApplyPatchToolCallOutput
from .response_custom_tool_call_output_item import ResponseCustomToolCallOutputItem
from .response_computer_tool_call_output_item import ResponseComputerToolCallOutputItem
from .response_function_tool_call_output_item import ResponseFunctionToolCallOutputItem
from .response_function_shell_tool_call_output import ResponseFunctionShellToolCallOutput

__all__ = [
    "ResponseItem",
    "AdditionalTools",
    "Program",
    "ProgramOutput",
    "ImageGenerationCall",
    "ImageGenerationCallError",
    "ImageGenerationCallErrorModerationDetails",
    "LocalShellCall",
    "LocalShellCallAction",
    "LocalShellCallOutput",
    "McpListTools",
    "McpListToolsTool",
    "McpApprovalRequest",
    "McpApprovalResponse",
    "McpCall",
]


class AdditionalTools(BaseModel):
    id: str
    """The unique ID of the additional tools item."""

    role: Literal["unknown", "user", "assistant", "system", "critic", "discriminator", "developer", "tool"]
    """The role that provided the additional tools."""

    tools: List[Tool]
    """The additional tool definitions made available at this item."""

    type: Literal["additional_tools"]
    """The type of the item. Always `additional_tools`."""


class Program(BaseModel):
    id: str
    """The unique ID of the program item."""

    call_id: str
    """The stable call ID of the program item."""

    code: str
    """The JavaScript source executed by programmatic tool calling."""

    fingerprint: str
    """Opaque program replay fingerprint that must be round-tripped."""

    type: Literal["program"]
    """The type of the item. Always `program`."""


class ProgramOutput(BaseModel):
    id: str
    """The unique ID of the program output item."""

    call_id: str
    """The call ID of the program item."""

    result: str
    """The result produced by the program item."""

    status: Literal["completed", "incomplete"]
    """The terminal status of the program output item."""

    type: Literal["program_output"]
    """The type of the item. Always `program_output`."""


class ImageGenerationCallErrorModerationDetails(BaseModel):
    """Public details for a `moderation_blocked` error, when available."""

    categories: List[str]
    """Public moderation categories. New category values may be added over time."""

    moderation_stage: Literal["input", "output", "unknown"]
    """The stage where moderation blocked the image generation call."""


class ImageGenerationCallError(BaseModel):
    """Details of a moderation failure, when available."""

    code: Optional[str] = None
    """The error code."""

    message: str
    """A description of the error."""

    param: Optional[str] = None
    """The related request parameter."""

    type: str
    """The error type."""

    moderation_details: Optional[ImageGenerationCallErrorModerationDetails] = None
    """Public details for a `moderation_blocked` error, when available."""


class ImageGenerationCall(BaseModel):
    """An image generation request made by the model."""

    id: str
    """The unique ID of the image generation call."""

    result: Optional[str] = None
    """The generated image encoded in base64."""

    status: Literal["in_progress", "completed", "generating", "failed"]
    """The status of the image generation call."""

    type: Literal["image_generation_call"]
    """The type of the image generation call. Always `image_generation_call`."""

    action: Optional[Literal["generate", "edit", "auto"]] = None
    """The action used for image generation."""

    background: Optional[Literal["transparent", "opaque", "auto"]] = None
    """The background setting used for generation."""

    error: Optional[ImageGenerationCallError] = None
    """Details of a moderation failure, when available."""

    output_format: Optional[Literal["png", "webp", "jpeg"]] = None
    """The output format used for generation."""

    quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto"]] = None
    """The quality of the image generated by the image generation tool call.

    One of `low`, `medium`, `high`, `xhigh`, `max`, or `auto`.
    """

    revised_prompt: Optional[str] = None
    """The prompt that was used after any model prompt rewriting."""

    size: Union[str, Literal["1024x1024", "1024x1536", "1536x1024"], None] = None
    """The image dimensions as a `WIDTHxHEIGHT` string, for example `1536x864`."""


class LocalShellCallAction(BaseModel):
    """Execute a shell command on the server."""

    command: List[str]
    """The command to run."""

    env: Dict[str, str]
    """Environment variables to set for the command."""

    type: Literal["exec"]
    """The type of the local shell action. Always `exec`."""

    timeout_ms: Optional[int] = None
    """Optional timeout in milliseconds for the command."""

    user: Optional[str] = None
    """Optional user to run the command as."""

    working_directory: Optional[str] = None
    """Optional working directory to run the command in."""


class LocalShellCall(BaseModel):
    """A tool call to run a command on the local shell."""

    id: str
    """The unique ID of the local shell call."""

    action: LocalShellCallAction
    """Execute a shell command on the server."""

    call_id: str
    """The unique ID of the local shell tool call generated by the model."""

    status: Literal["in_progress", "completed", "incomplete"]
    """The status of the local shell call."""

    type: Literal["local_shell_call"]
    """The type of the local shell call. Always `local_shell_call`."""


class LocalShellCallOutput(BaseModel):
    """The output of a local shell tool call."""

    id: str
    """The unique ID of the local shell tool call generated by the model."""

    output: str
    """A JSON string of the output of the local shell tool call."""

    type: Literal["local_shell_call_output"]
    """The type of the local shell tool call output. Always `local_shell_call_output`."""

    status: Optional[Literal["in_progress", "completed", "incomplete"]] = None
    """The status of the item. One of `in_progress`, `completed`, or `incomplete`."""


class McpListToolsTool(BaseModel):
    """A tool available on an MCP server."""

    input_schema: object
    """The JSON schema describing the tool's input."""

    name: str
    """The name of the tool."""

    annotations: Optional[object] = None
    """Additional annotations about the tool."""

    description: Optional[str] = None
    """The description of the tool."""


class McpListTools(BaseModel):
    """A list of tools available on an MCP server."""

    id: str
    """The unique ID of the list."""

    server_label: str
    """The label of the MCP server."""

    tools: List[McpListToolsTool]
    """The tools available on the server."""

    type: Literal["mcp_list_tools"]
    """The type of the item. Always `mcp_list_tools`."""

    error: Optional[str] = None
    """Error message if the server could not list tools."""


class McpApprovalRequest(BaseModel):
    """A request for human approval of a tool invocation."""

    id: str
    """The unique ID of the approval request."""

    arguments: str
    """A JSON string of arguments for the tool."""

    name: str
    """The name of the tool to run."""

    server_label: str
    """The label of the MCP server making the request."""

    type: Literal["mcp_approval_request"]
    """The type of the item. Always `mcp_approval_request`."""


class McpApprovalResponse(BaseModel):
    """A response to an MCP approval request."""

    id: str
    """The unique ID of the approval response"""

    approval_request_id: str
    """The ID of the approval request being answered."""

    approve: bool
    """Whether the request was approved."""

    type: Literal["mcp_approval_response"]
    """The type of the item. Always `mcp_approval_response`."""

    reason: Optional[str] = None
    """Optional reason for the decision."""


class McpCall(BaseModel):
    """An invocation of a tool on an MCP server."""

    id: str
    """The unique ID of the tool call."""

    arguments: str
    """A JSON string of the arguments passed to the tool."""

    name: str
    """The name of the tool that was run."""

    server_label: str
    """The label of the MCP server running the tool."""

    type: Literal["mcp_call"]
    """The type of the item. Always `mcp_call`."""

    approval_request_id: Optional[str] = None
    """
    Unique identifier for the MCP tool call approval request. Include this value in
    a subsequent `mcp_approval_response` input to approve or reject the
    corresponding tool call.
    """

    error: Optional[McpToolCallError] = None
    """The error from the tool call, if any."""

    output: Optional[str] = None
    """The output from the tool call."""

    status: Optional[Literal["in_progress", "completed", "incomplete", "calling", "failed"]] = None
    """The status of the tool call.

    One of `in_progress`, `completed`, `incomplete`, `calling`, or `failed`.
    """


ResponseItem: TypeAlias = Annotated[
    Union[
        ResponseInputMessageItem,
        ResponseOutputMessage,
        ResponseFileSearchToolCall,
        ResponseComputerToolCall,
        ResponseComputerToolCallOutputItem,
        ResponseFunctionWebSearch,
        ResponseFunctionToolCallItem,
        ResponseFunctionToolCallOutputItem,
        ResponseToolSearchCall,
        ResponseToolSearchOutputItem,
        AdditionalTools,
        ResponseConfigurationUpdateItem,
        ResponseReasoningItem,
        Program,
        ProgramOutput,
        ResponseCompactionItem,
        ImageGenerationCall,
        ResponseCodeInterpreterToolCall,
        LocalShellCall,
        LocalShellCallOutput,
        ResponseFunctionShellToolCall,
        ResponseFunctionShellToolCallOutput,
        ResponseApplyPatchToolCall,
        ResponseApplyPatchToolCallOutput,
        McpListTools,
        McpApprovalRequest,
        McpApprovalResponse,
        McpCall,
        ResponseCustomToolCallItem,
        ResponseCustomToolCallOutputItem,
    ],
    PropertyInfo(discriminator="type"),
]
