# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["ResponseOutputRefusalParam"]


class ResponseOutputRefusalParam(TypedDict, total=False):
    """A refusal from the model."""

    refusal: Required[str]
    """The refusal explanation from the model."""

    type: Required[Literal["refusal"]]
    """The type of the refusal. Always `refusal`."""
