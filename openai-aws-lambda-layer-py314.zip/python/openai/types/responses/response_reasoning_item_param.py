# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable, Optional
from typing_extensions import Literal, Required, TypedDict

__all__ = ["ResponseReasoningItemParam", "Summary", "Content"]


class Summary(TypedDict, total=False):
    """A summary text from the model."""

    text: Required[str]
    """A summary of the reasoning output from the model so far."""

    type: Required[Literal["summary_text"]]
    """The type of the object. Always `summary_text`."""


class Content(TypedDict, total=False):
    """Reasoning text from the model."""

    text: Required[str]
    """The reasoning text from the model."""

    type: Required[Literal["reasoning_text"]]
    """The type of the reasoning text. Always `reasoning_text`."""


class ResponseReasoningItemParam(TypedDict, total=False):
    """
    A description of the chain of thought used by a reasoning model while generating
    a response. Be sure to include these items in your `input` to the Responses API
    for subsequent turns of a conversation if you are manually
    [managing context](https://developers.openai.com/api/docs/guides/conversation-state).
    """

    id: Required[str]
    """The unique identifier of the reasoning content."""

    summary: Required[Iterable[Summary]]
    """Reasoning summary content."""

    type: Required[Literal["reasoning"]]
    """The type of the object. Always `reasoning`."""

    content: Iterable[Content]
    """Reasoning text content."""

    encrypted_content: Optional[str]
    """The encrypted content of the reasoning item.

    This is populated by default for reasoning items returned by
    `POST /v1/responses` and WebSocket `response.create` requests.

    When streaming, use the completed reasoning item and its `encrypted_content`
    from the `response.output_item.done` event in subsequent requests. The
    `encrypted_content` in `response.output_item.added` may be incomplete. This is
    especially important when `store` is `false` or when using Zero Data Retention.
    """

    status: Literal["in_progress", "completed", "incomplete"]
    """The status of the item.

    One of `in_progress`, `completed`, or `incomplete`. Populated when items are
    returned via API.
    """
